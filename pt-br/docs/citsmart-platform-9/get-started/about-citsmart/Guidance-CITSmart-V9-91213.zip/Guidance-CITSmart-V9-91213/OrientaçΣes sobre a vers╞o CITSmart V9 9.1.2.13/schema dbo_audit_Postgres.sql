DROP TABLE IF EXISTS dbo_audit.auditdetail;

DROP TABLE IF EXISTS dbo_audit.auditheader;

DO $$ 
BEGIN 
	IF EXISTS(SELECT 'X' FROM information_schema.schemata WHERE schema_name = 'dbo_audit') 
	THEN 
		IF NOT EXISTS(SELECT 'X' FROM information_schema.tables 
								 WHERE table_schema = 'dbo_audit' 
									 AND table_name = 'auditheader') 
		THEN 
			CREATE TABLE dbo_audit.auditheader ( 
				id bigint NOT NULL, 
				created TIMESTAMP WITHOUT TIME ZONE, 
				eventtype CHARACTER VARYING(255), 
				eventmode CHARACTER VARYING(255), 
				ip CHARACTER VARYING(255), 
				entity CHARACTER VARYING(255), 
				keyvalue CHARACTER VARYING(255), 
				identifier TEXT, 
				createdby INTEGER, 
				ticketoccurrence_id INTEGER, 
				CONSTRAINT auditheader_pkey PRIMARY KEY (id), 
				CONSTRAINT auditheader_user_fk FOREIGN KEY (createdby) 
					REFERENCES usuario (idusuario), 
				CONSTRAINT auditdetail_occurrence_fk FOREIGN KEY (ticketoccurrence_id) 
					REFERENCES ocorrenciasolicitacao (idocorrencia) 
			); 
			
			CREATE INDEX audit_user_idx ON dbo_audit.auditheader (createdby ASC); 
		
			CREATE INDEX audit_created_idx ON dbo_audit.auditheader (created ASC); 
			
			CREATE INDEX audit_eventtype_idx ON dbo_audit.auditheader (eventtype ASC); 
			
			CREATE INDEX audit_ip_idx ON dbo_audit.auditheader (ip ASC); 
			
			CREATE INDEX audit_entity_idx ON dbo_audit.auditheader (entity ASC); 
			
			CREATE INDEX audit_keyvalue_idx ON dbo_audit.auditheader (keyvalue ASC); 
			
			CREATE INDEX audit_identifier_idx ON dbo_audit.auditheader (identifier ASC); 
			
			CREATE INDEX audit_occurrence_idx ON dbo_audit.auditheader (ticketoccurrence_id ASC); 
			
			CREATE INDEX ocorr_idcategory_idx ON ocorrenciasolicitacao (idoccurrencecategory ASC); 
			
			CREATE INDEX ocorr_idocorrenciapai_idx ON ocorrenciasolicitacao (idocorrenciapai ASC); 
			
			CREATE INDEX ocorr_datafim_idx ON ocorrenciasolicitacao (datafim ASC); 
			
			INSERT INTO dbo_audit.auditheader (id, created, eventtype, ip, entity, keyvalue, createdby, eventmode, identifier, ticketoccurrence_id) 
				SELECT 
					NEXTVAL('hibernate_sequence'),
					TO_TIMESTAMP(TO_CHAR(dataregistro, 'YYYY-MM-DD') || ' ' || horaregistro, 'YYYY-MM-DD HH24:MI'), 
					'TICKET_OCCURRENCE', 
					'127.0.0.1', 
					'br.com.centralit.citcorpore.bean.SolicitacaoServicoDTO', 
					idsolicitacaoservico, 
					COALESCE(registradoporidusuario, 
					(SELECT MAX(idusuario) FROM usuario WHERE login = registradopor)), 
					CASE 
						WHEN COALESCE(registradoporidusuario, (SELECT MAX(idusuario) FROM usuario WHERE login = registradopor)) IS NULL THEN 'AUTOMATICALLY' 
						ELSE 'MANUALLY' 
					END, 
					idsolicitacaoservico, 
					idocorrencia 
				FROM ocorrenciasolicitacao WHERE idsolicitacaoservico IS NOT NULL AND idoccurrencecategory <> 1; 
		END IF; 
		
		IF NOT EXISTS(SELECT 'X' FROM information_schema.tables 
								 WHERE table_schema = 'dbo_audit' 
									 AND table_name = 'auditdetail') 
		THEN 
			CREATE TABLE dbo_audit.auditdetail ( 
				id bigint NOT NULL, 
				difftype CHARACTER VARYING(255), 
				entity CHARACTER VARYING(255), 
				leftlabel CHARACTER VARYING(255), 
				leftvalue TEXT, 
				property CHARACTER VARYING(255), 
				rightlabel CHARACTER VARYING(255), 
				rightvalue TEXT, 
				header_id BIGINT NOT NULL, 
				mainobject BOOLEAN, 
				colindex INTEGER, 
				CONSTRAINT auditdetail_pkey PRIMARY KEY (id), 
				CONSTRAINT auditdetail_header_fk FOREIGN KEY (header_id) 
					REFERENCES dbo_audit.auditheader (id) 
			); 
		END IF; 
	ELSE 
		RAISE EXCEPTION 'Audit tables were not created because the dbo_audit scheme does not exist!'; 
	END IF; 
END$$;;